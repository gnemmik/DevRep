public class  Main {
	
    String voice;

	
 
    Main  () {  voice = "This mobile has : _ Voice call";  Video = "                  _ Video call";  string = "                  _ SMS";  mms = "                  _ MMS";  alarm = "                  _ Alarm";  games = "                  _ Games";  iOS = "                  _ iOS";  java = "                  _ Java";  mp3 = "                  _ MP3";  mp4 = "                  _ MP4";  camera = "                  _ Camera";  Wifi = "                  _ Wifi";  bluetooth = "                  _ Bluetooth";  usb = "                  _ USB"; }

	
 
     private void  print__wrappee__Voice  () { 
       System.out.println(voice); 
    }

	
 
     private void  print__wrappee__Video  () {
        print__wrappee__Voice();
        System.out.println( Video );
    }

	
 
     private void  print__wrappee__SMS  () {
        print__wrappee__Video();
        System.out.println( string );
    }

	
 
     private void  print__wrappee__MMS  () {
        print__wrappee__SMS();
        System.out.println( mms );
    }

	
 
     private void  print__wrappee__Alarm  () {
        print__wrappee__MMS();
        System.out.println( alarm );
    }

	
 
     private void  print__wrappee__Games  () {
        print__wrappee__Alarm();
        System.out.println( games );
    }

	
 
     private void  print__wrappee__iOS  () {
        print__wrappee__Games();
        System.out.println( iOS );
    }

	
 
     private void  print__wrappee__Java  () {
        print__wrappee__iOS();
        System.out.println( java );
    }

	
 
     private void  print__wrappee__MP3  () {
        print__wrappee__Java();
        System.out.println( mp3 );
    }

	
 
     private void  print__wrappee__MP4  () {
        print__wrappee__MP3();
        System.out.println( mp4 );
    }

	
 
     private void  print__wrappee__Camera  () {
        print__wrappee__MP4();
        System.out.println( camera );
    }

	
 
     private void  print__wrappee__Wifi  () {
        print__wrappee__Camera();
        System.out.println( Wifi );
    }

	
 
     private void  print__wrappee__Bluetooth  () {
        print__wrappee__Wifi();
        System.out.println( bluetooth );
    }

	
 
    void print() {
        print__wrappee__Bluetooth();
        System.out.println( usb );
    }

	
 
    static Main me;

	
 
    public static void main( String[] args ) {
      me = new Main();
      me.print();
    }

	
    String Video;

	
    String string;

	
    String mms;

	
    String alarm;

	
    String games;

	
    String iOS;

	
    String java;

	
    String mp3;

	
    String mp4;

	
    String camera;

	
    String Wifi;

	
    String bluetooth;

	
    String usb;


}
