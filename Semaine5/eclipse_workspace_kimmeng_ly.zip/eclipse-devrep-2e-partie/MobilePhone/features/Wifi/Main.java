class Main {
    String Wifi;
 
    Main() { Wifi = "                  _ Wifi"; }
 
    void print() {
        original();
        System.out.println( Wifi );
    }
}