class Main {
    String games;
 
    Main() { games = "                  _ Games"; }
 
    void print() {
        original();
        System.out.println( games );
    }
}