class Main {
    String bluetooth;
 
    Main() { bluetooth = "                  _ Bluetooth"; }
 
    void print() {
        original();
        System.out.println( bluetooth );
    }
}