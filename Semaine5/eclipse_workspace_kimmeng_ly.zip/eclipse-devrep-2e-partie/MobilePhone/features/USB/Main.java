class Main {
    String usb;
 
    Main() { usb = "                  _ USB"; }
 
    void print() {
        original();
        System.out.println( usb );
    }
}