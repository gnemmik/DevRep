class Main {
    String android;
 
    Main() { android = "                  _ Android"; }
 
    void print() {
        original();
        System.out.println( android );
    }
}