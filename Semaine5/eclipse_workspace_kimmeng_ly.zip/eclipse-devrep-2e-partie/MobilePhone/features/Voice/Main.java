public class Main {
    String voice;
 
    Main() {  voice = "This mobile has : _ Voice call"; }
 
    void print() { 
       System.out.println(voice); 
    }
 
    static Main me;
 
    public static void main( String[] args ) {
      me = new Main();
      me.print();
    }
}