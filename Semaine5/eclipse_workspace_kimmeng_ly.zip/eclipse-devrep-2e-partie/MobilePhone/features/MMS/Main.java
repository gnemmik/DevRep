class Main {
    String mms;
 
    Main() { mms = "                  _ MMS"; }
 
    void print() {
        original();
        System.out.println( mms );
    }
}