class Main {
    String Video;
 
    Main() { Video = "                  _ Video call"; }
 
    void print() {
        original();
        System.out.println( Video );
    }
}