class Main {
    String mp3;
 
    Main() { mp3 = "                  _ MP3"; }
 
    void print() {
        original();
        System.out.println( mp3 );
    }
}