class Main {
    String camera;
 
    Main() { camera = "                  _ Camera"; }
 
    void print() {
        original();
        System.out.println( camera );
    }
}