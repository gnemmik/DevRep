class Main {
    String mp4;
 
    Main() { mp4 = "                  _ MP4"; }
 
    void print() {
        original();
        System.out.println( mp4 );
    }
}