class Main {
    String string;
 
    Main() { string = "                  _ SMS"; }
 
    void print() {
        original();
        System.out.println( string );
    }
}