class Main {
    String java;
 
    Main() { java = "                  _ Java"; }
 
    void print() {
        original();
        System.out.println( java );
    }
}