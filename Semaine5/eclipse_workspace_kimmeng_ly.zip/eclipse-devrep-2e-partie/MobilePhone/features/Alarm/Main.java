class Main {
    String alarm;
 
    Main() { alarm = "                  _ Alarm"; }
 
    void print() {
        original();
        System.out.println( alarm );
    }
}