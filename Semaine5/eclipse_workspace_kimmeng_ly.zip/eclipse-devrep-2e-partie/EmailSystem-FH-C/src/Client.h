#include "Email.h"
#include "slist.h"
struct  client {
  char *name; 
  NODE *outgoingBuffer; 
  NODE *userPublicKeyPairs; 
  char *privateKey; 
  char *autoResponse; 
  int idCounter;};


void outgoing (struct client *client, struct email *msg);


void incoming (struct client *client, struct email *msg);
struct  userPublicKeyPair {
  char *user; 
  char *publicKey;};


int isKeyPairValid (char *publicKey, char *privateKey);
// TODO remove
void encrypt (struct client *client, struct email *msg);


void autoRespond (struct client *client, struct email *msg);
// TODO remove
void decrypt (struct client *client, struct email *msg);


void addMessageID (struct client *client, struct email *msg);
