struct client
{
  char *forwardReceiver;
};

// TODO remove
void forward (struct client *client, struct email *msg);
