// TODO remove
void decrypt (struct client *client, struct email *msg);
