// TODO remove
void encrypt (struct client *client, struct email *msg);
