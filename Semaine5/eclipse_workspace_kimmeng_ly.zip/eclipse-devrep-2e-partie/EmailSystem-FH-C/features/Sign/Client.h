// TODO remove
void sign (struct client *client, struct email *msg);
