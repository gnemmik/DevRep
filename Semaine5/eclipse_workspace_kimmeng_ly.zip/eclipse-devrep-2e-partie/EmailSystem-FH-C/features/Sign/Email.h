struct email
{
  int isSigned;
  char *signKey;
};

int isSigned (struct email *msg);
