struct client
{
  char *autoResponse;
};

void autoRespond (struct client *client, struct email *msg);
