struct client
{
  int idCounter;
};

void addMessageID (struct client *client, struct email *msg);
