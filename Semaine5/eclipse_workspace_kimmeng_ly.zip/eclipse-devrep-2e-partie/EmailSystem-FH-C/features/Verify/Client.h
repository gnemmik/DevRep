//TODO remove
void verify (struct client *client, struct email *msg);
