struct email
{
  int isSignatureVerified;
};

int isVerified (struct email *msg);
