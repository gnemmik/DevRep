/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Light Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getLightSensor()
 * @model
 * @generated
 */
public interface LightSensor extends Sensor {
} // LightSensor
