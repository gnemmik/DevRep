/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Home</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getHome()
 * @model
 * @generated
 */
public interface Home extends Behavior {
} // Home
