/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Distance Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getDistanceSensor()
 * @model
 * @generated
 */
public interface DistanceSensor extends Sensor {
} // DistanceSensor
