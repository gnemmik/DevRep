/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Escape</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getEscape()
 * @model
 * @generated
 */
public interface Escape extends Behavior {
} // Escape
