/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Left Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getLeftMotor()
 * @model
 * @generated
 */
public interface LeftMotor extends Actuator {
} // LeftMotor
