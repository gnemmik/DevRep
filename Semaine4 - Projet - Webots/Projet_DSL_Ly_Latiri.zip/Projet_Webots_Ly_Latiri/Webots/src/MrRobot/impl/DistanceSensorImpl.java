/**
 */
package MrRobot.impl;

import MrRobot.DistanceSensor;
import MrRobot.MrRobotPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Distance Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DistanceSensorImpl extends SensorImpl implements DistanceSensor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DistanceSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MrRobotPackage.Literals.DISTANCE_SENSOR;
	}

} //DistanceSensorImpl
