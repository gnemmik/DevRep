/**
 */
package MrRobot.impl;

import MrRobot.LightSensor;
import MrRobot.MrRobotPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Light Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LightSensorImpl extends SensorImpl implements LightSensor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LightSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MrRobotPackage.Literals.LIGHT_SENSOR;
	}

} //LightSensorImpl
