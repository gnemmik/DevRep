/**
 */
package MrRobot.impl;

import MrRobot.MrRobotPackage;
import MrRobot.RightMotor;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Right Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RightMotorImpl extends ActuatorImpl implements RightMotor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RightMotorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MrRobotPackage.Literals.RIGHT_MOTOR;
	}

} //RightMotorImpl
