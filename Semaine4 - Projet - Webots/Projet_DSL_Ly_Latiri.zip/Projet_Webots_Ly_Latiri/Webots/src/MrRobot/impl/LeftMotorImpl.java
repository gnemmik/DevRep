/**
 */
package MrRobot.impl;

import MrRobot.LeftMotor;
import MrRobot.MrRobotPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Left Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LeftMotorImpl extends ActuatorImpl implements LeftMotor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LeftMotorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MrRobotPackage.Literals.LEFT_MOTOR;
	}

} //LeftMotorImpl
