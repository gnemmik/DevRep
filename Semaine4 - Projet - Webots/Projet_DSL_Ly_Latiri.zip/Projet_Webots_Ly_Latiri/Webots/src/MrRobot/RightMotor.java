/**
 */
package MrRobot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Right Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see MrRobot.MrRobotPackage#getRightMotor()
 * @model
 * @generated
 */
public interface RightMotor extends Actuator {
} // RightMotor
